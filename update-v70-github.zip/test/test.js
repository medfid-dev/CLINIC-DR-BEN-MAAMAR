'use strict';
/* اختبار شامل: node test/test.js */
const { spawn } = require('child_process'), fs = require('fs'), os = require('os'), path = require('path'), assert = require('assert');
const port = 4100 + Math.floor(Math.random() * 500), base = `http://127.0.0.1:${port}`;
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'cc-'));
const pushPort = port + 1000, pushes = [];   // خادم دفع وهمي يلتقط الرسائل المشفّرة
const mock = require('http').createServer((req, res) => { const ch = []; req.on('data', c => ch.push(c)); req.on('end', () => { pushes.push({ url: req.url, headers: req.headers, body: Buffer.concat(ch) }); res.writeHead(req.url.startsWith('/gone') ? 410 : 201); res.end(); }); }).listen(pushPort, '127.0.0.1');
const srv = spawn(process.execPath, [path.join(__dirname, '..', 'server.js')], { env: { ...process.env, PORT: port, DATA_DIR: dir, PUSH_EXTRA_HOSTS: `127.0.0.1:${pushPort}`, OWNER_PASSWORD: 'owner-pass-123', REQUIRE_APPROVAL: 'false', REG_RATE_MAX: '1000' }, stdio: 'inherit' });
const crypto = require('crypto');
/* فكّ تشفير RFC 8291 كما يفعل المتصفح، للتحقق من صحة التنسيق */
function decryptPush(body, ecdh, auth) {
  const salt = body.subarray(0, 16), idlen = body[20], asPub = body.subarray(21, 21 + idlen), ct = body.subarray(21 + idlen), uaPub = ecdh.getPublicKey();
  const hk = (ikm, s, info, n) => Buffer.from(crypto.hkdfSync('sha256', ikm, s, info, n));
  const prk = hk(ecdh.computeSecret(asPub), auth, Buffer.concat([Buffer.from('WebPush: info\0'), uaPub, asPub]), 32);
  const d = crypto.createDecipheriv('aes-128-gcm', hk(prk, salt, Buffer.from('Content-Encoding: aes128gcm\0'), 16), hk(prk, salt, Buffer.from('Content-Encoding: nonce\0'), 12));
  d.setAuthTag(ct.subarray(ct.length - 16)); const pt = Buffer.concat([d.update(ct.subarray(0, ct.length - 16)), d.final()]);
  return JSON.parse(pt.subarray(0, pt.lastIndexOf(2)).toString('utf8'));
}
const mkSub = path => { const e = crypto.createECDH('prime256v1'); e.generateKeys(); const auth = crypto.randomBytes(16); return { e, auth, sub: { endpoint: `http://127.0.0.1:${pushPort}${path}`, keys: { p256dh: e.getPublicKey().toString('base64url'), auth: auth.toString('base64url') } } }; };
const J = async (m, p, tok, body, raw) => {
  const r = await fetch(base + p, { method: m, headers: { ...(tok ? { Authorization: 'Bearer ' + tok } : {}), ...(raw ? { 'Content-Type': 'image/jpeg' } : body ? { 'Content-Type': 'application/json' } : {}) }, body: raw || (body ? JSON.stringify(body) : undefined) });
  let j = null; try { j = await r.json(); } catch (e) {} return { s: r.status, j };
};
let pass = 0; const ok = (c, msg) => { assert.ok(c, msg); pass++; console.log('  ✓', msg); };
async function sse(url, onEvt) { const ac = new AbortController(); const r = await fetch(url, { signal: ac.signal }); const rd = r.body.getReader(), dec = new TextDecoder(); let buf = ''; (async () => { try { for (;;) { const { value, done } = await rd.read(); if (done) break; buf += dec.decode(value); let i; while ((i = buf.indexOf('\n\n')) >= 0) { const blk = buf.slice(0, i); buf = buf.slice(i + 2); const ev = /event: (\w+)/.exec(blk), d = /data: (.*)/.exec(blk); if (ev && d) onEvt(ev[1], JSON.parse(d[1])); } } } catch (e) {} })(); return ac; }
const wait = ms => new Promise(r => setTimeout(r, ms));
const pat = (n, o) => ({ name: n, birthYear: 1990, gender: 'ذكر', reason: 'قلع أسنان', tooth: '16', phone: '0550000000', ...o });

(async () => {
  for (let i = 0; i < 50; i++) { try { await fetch(base + '/healthz'); break; } catch (e) { await wait(100); } }
  try {
    console.log('التسجيل والدخول');
    let r = await J('POST', '/api/register', null, { clinicName: 'عيادة أ', doctorName: 'د. أحمد', username: 'ahmed', password: 'password1' });
    ok(r.s === 201 && r.j.token, 'تسجيل طبيب أ'); const A = r.j.token;
    r = await J('POST', '/api/register', null, { clinicName: 'عيادة ب', doctorName: 'د. سارة', username: 'sara', password: 'password2' });
    ok(r.s === 201, 'تسجيل طبيب ب'); const B = r.j.token;
    r = await J('POST', '/api/register', null, { clinicName: 'x', doctorName: 'y', username: 'AHMED', password: 'password3' }); ok(r.s === 409, 'منع تكرار اسم المستخدم');
    r = await J('POST', '/api/register', null, { clinicName: 'x', doctorName: 'y', username: 'zed', password: '123' }); ok(r.s === 400, 'رفض كلمة مرور قصيرة');
    r = await J('POST', '/api/login/doctor', null, { username: 'ahmed', password: 'wrong' }); ok(r.s === 401, 'رفض كلمة مرور خاطئة');
    r = await J('POST', '/api/login/doctor', null, { username: 'ahmed', password: 'password1' }); ok(r.s === 200, 'دخول الطبيب');
    const meA = (await J('GET', '/api/state', A)).j.me, meB = (await J('GET', '/api/state', B)).j.me;
    ok(meA.code && meB.code && meA.code !== meB.code, 'لكل عيادة رمز مختلف');
    r = await J('POST', '/api/nurses', A, { name: 'فاطمة', phone: '0661', password: 'nurse123' }); ok(r.s === 201, 'إضافة ممرضة');
    r = await J('POST', '/api/login/nurse', null, { code: meB.code, name: 'فاطمة', password: 'nurse123' }); ok(r.s === 401, 'ممرضة أ لا تدخل عيادة ب');
    r = await J('POST', '/api/login/nurse', null, { code: meA.code.toLowerCase(), name: 'فاطمة', password: 'nurse123' }); ok(r.s === 200, 'دخول الممرضة برمز العيادة'); const N = r.j.token;
    r = await J('GET', '/api/nurses', N); ok(r.s === 403, 'الممرضة لا ترى قائمة الممرضات');
    r = await J('GET', '/api/archive', N); ok(r.s === 403, 'الممرضة لا ترى الأرشيف');

    console.log('العزل بين الأطباء');
    const p1 = (await J('POST', '/api/patients', N, pat('مريض1'))).j, p2 = (await J('POST', '/api/patients', N, pat('مريض2'))).j, p3 = (await J('POST', '/api/patients', N, pat('مريض3'))).j;
    ok(p1.ticketNo === 1 && p3.ticketNo === 3, 'ترقيم التذاكر');
    const stB = (await J('GET', '/api/state', B)).j; ok(stB.patients.length === 0, 'الطبيب ب لا يرى مرضى أ');
    r = await J('PUT', `/api/patients/${p1.id}`, B, pat('اختراق')); ok(r.s === 404, 'ب لا يعدّل مريض أ');
    r = await J('DELETE', `/api/patients/${p1.id}`, B); ok(r.s === 404, 'ب لا يحذف مريض أ');
    r = await J('POST', `/api/patients/${p1.id}/enter`, B); ok(r.s === 404, 'ب لا يُدخل مريض أ');
    r = await J('GET', '/api/state'); ok(r.s === 401, 'بدون رمز: 401');
    r = await J('GET', '/api/state', 'bogus'); ok(r.s === 401, 'رمز مزيّف: 401');

    console.log('الطابور وتخطي الدور');
    const events = [], ac = await sse(await (async () => { const t = (await J('POST', '/api/stream-ticket', A)).j.ticket; return `${base}/api/stream?ticket=${t}`; })(), (e, d) => events.push([e, d]));
    const nEv = [], acN = await sse(`${base}/api/stream?ticket=${(await J('POST', '/api/stream-ticket', N)).j.ticket}`, (e, d) => nEv.push([e, d]));
    await wait(200); ok(events.some(e => e[0] === 'state' && e[1].patients.length === 3), 'بث الحالة الأولية للطبيب');
    r = await J('GET', `/api/stream?ticket=${(await J('POST', '/api/stream-ticket', A)).j.ticket}x`); ok(r.s === 401, 'تذكرة بث خاطئة مرفوضة');
    r = await J('POST', `/api/patients/${p2.id}/enter`, N); ok(r.s === 202 && r.j.skipRequested, 'ممرضة تطلب تخطي الدور');
    await wait(150); ok(events.some(e => e[0] === 'state' && e[1].skipRequests.length === 1), 'الطبيب يتلقى طلب التخطي فوراً');
    r = await J('POST', `/api/patients/${p2.id}/skip`, N, { allow: true }); ok(r.s === 403, 'الممرضة لا تسمح لنفسها');
    r = await J('POST', `/api/patients/${p2.id}/skip`, A, { allow: false }); await wait(150);
    ok(nEv.some(e => e[0] === 'notify' && e[1].type === 'skip_denied'), 'إشعار الرفض يصل للممرضة');
    r = await J('POST', `/api/patients/${p1.id}/enter`, N); ok(r.s === 200 && r.j.status === 'in', 'دخول الأول بلا تخطي');
    r = await J('POST', `/api/patients/${p2.id}/enter`, N); ok(r.s === 409, 'لا دخول مزدوج');
    const jpeg = Buffer.concat([Buffer.from([0xFF, 0xD8, 0xFF, 0xE0]), Buffer.alloc(100, 1)]);
    r = await J('POST', `/api/patients/${p1.id}/images`, N, null, jpeg); ok(r.s === 403, 'الممرضة لا ترفع صوراً');
    r = await J('POST', `/api/patients/${p1.id}/images`, A, null, Buffer.from('not an image')); ok(r.s === 400, 'رفض ملف ليس JPEG');
    r = await J('POST', `/api/patients/${p1.id}/images`, A, null, jpeg); ok(r.s === 201, 'رفع صورة'); const imgId = r.j.id;
    let g = await fetch(`${base}/api/records/${p1.id}/images/${imgId}`, { headers: { Authorization: 'Bearer ' + A } }); ok(g.status === 200, 'تنزيل الصورة للطبيب صاحبها');
    g = await fetch(`${base}/api/records/${p1.id}/images/${imgId}`, { headers: { Authorization: 'Bearer ' + B } }); ok(g.status === 404, 'الطبيب ب لا يصل لصورة أ');
    g = await fetch(`${base}/api/records/${p1.id}/images/${imgId}`, { headers: { Authorization: 'Bearer ' + N } }); ok(g.status === 403, 'الممرضة لا تصل للصور');

    console.log('تذكرة المريض (الخصوصية)');
    const t2 = (await J('GET', '/api/state', A)).j.patients.find(x => x.id === p2.id).ticket;
    r = await J('GET', `/api/ticket/${t2}`); ok(r.s === 200 && r.j.state === 'waiting' && r.j.ahead === 0 && r.j.busy === true, 'تذكرة 2: لا أحد أمامه والطبيب مشغول');
    const t3 = p3.ticket; r = await J('GET', `/api/ticket/${t3}`); ok(r.j.ahead === 1, 'تذكرة 3: واحد أمامه');
    const dump = JSON.stringify({ ...r.j, updated: 0 }); ok(!dump.includes('مريض1') && !dump.includes('مريض2') && !dump.includes('0550000000') && !dump.includes('1990') && !dump.includes('16'), 'التذكرة لا تكشف اسم/هاتف/سن أي مريض آخر');
    ok(Object.keys(r.j).sort().join() === 'ahead,busy,clinic,estMin,firstName,state,ticketNo,updated', 'حقول التذكرة محصورة');
    r = await J('GET', '/api/ticket/AAAAAAAAAAAAAAAAAAAAAAAA'); ok(r.s === 404, 'رمز تذكرة مجهول 404');
    r = await J('GET', '/api/ticket/../state'); ok(r.s === 401 || r.s === 404, 'لا ثغرة مسار في التذكرة');
    const tEv = []; const acT = await sse(`${base}/api/ticket/${t3}/stream`, (e, d) => tEv.push(d)); await wait(150);
    r = await J('POST', `/api/patients/${p1.id}/finish`, N, { treatment: 'قلع' }); ok(r.s === 403, 'الممرضة لا تنهي المعاينة');
    r = await J('POST', `/api/patients/${p1.id}/finish`, A, { treatment: 'قلع', notes: 'ملاحظة', teeth: ['16', '55', '99', 'x', '16'], price: '2000' }); ok(r.s === 200 && JSON.stringify(r.j.teeth) === '["16","55"]' && r.j.tooth === '16 55' && r.j.price === 2000, 'إنهاء المعاينة مع أسنان (FDI بالغ ولبني، تُرفض غير الصالحة)');
    await wait(200); ok(tEv.length >= 2 && tEv[tEv.length - 1].state === 'waiting' && tEv[tEv.length - 1].ahead === 1, 'تذكرة 3 تتلقى تحديثاً فورياً عبر البث');
    ok(nEv.some(e => e[1].type === 'finish'), 'الممرضة تُبلَّغ بانتهاء المعاينة');
    r = await J('GET', `/api/ticket/${p1.ticket}`); ok(r.j.state === 'done', 'تذكرة المنتهي: done');
    r = await J('POST', `/api/patients/${p2.id}/enter`, N); ok(r.s === 200, 'الثاني يدخل بعد الإنهاء');
    r = await J('PUT', `/api/patients/${p2.id}`, N, { name: 'ممنوع', birthYear: 1990 }); ok(r.s === 409, 'الممرضة لا تعدّل بيانات من في المعاينة');
    r = await J('PUT', `/api/patients/${p2.id}`, A, { name: 'اسم معدّل', birthYear: 1991, gender: 'أنثى', phone: '0555123456', reason: 'استشارة وطوارئ' }); ok(r.s === 200 && r.j.name === 'اسم معدّل' && r.j.gender === 'أنثى' && r.j.phone === '0555123456', 'الطبيب يعدّل بيانات المريض أثناء المعاينة');
    r = await J('GET', `/api/ticket/${t2}`); ok(r.j.state === 'in', 'تذكرة 2: دورك الآن');
    r = await J('GET', '/api/archive?name=مريض1', A); ok(r.j.total === 1 && r.j.items[0].images.length === 1, 'البحث في الأرشيف');
    ok(r.j.items[0].payments.length === 1 && r.j.items[0].payments[0].amt === 2000, 'الدفعة تظهر في سجل الأرشيف');
    { const iso = d => d.toLocaleDateString('en-CA'), tz = new Date().getTimezoneOffset(), n = new Date(), y = new Date(n.getTime() - 864e5), f = new Date(n.getTime() + 864e5), q = (a, b) => `/api/archive?from=${a}&to=${b}&tz=${tz}`;
      r = await J('GET', q(iso(n), iso(n)), A); ok(r.j.total === 1, 'فلتر اليوم يشمل سجل اليوم');
      r = await J('GET', q(iso(y), iso(y)), A); ok(r.j.total === 0, 'فلتر أمس لا يشمل سجل اليوم');
      r = await J('GET', q(iso(y), iso(f)), A); ok(r.j.total === 1, 'نطاق من أمس إلى غد يشمل السجل');
      r = await J('GET', q(iso(f), iso(y)), A); ok(r.j.total === 1, 'نطاق معكوس يُصحَّح تلقائياً');
      r = await J('GET', `/api/archive?from=${iso(f)}&tz=${tz}`, A); ok(r.j.total === 0, 'من الغد فصاعداً لا يشمل السجل');
      r = await J('GET', `/api/archive?to=${iso(y)}&tz=${tz}`, A); ok(r.j.total === 0, 'حتى أمس لا يشمل سجل اليوم');
      r = await J('GET', '/api/archive?from=bad&to=zzz', A); ok(r.s === 200 && r.j.total === 1, 'تاريخ غير صالح يُتجاهل'); }
    r = await J('GET', '/api/archive?name=مريض1', B); ok(r.j.total === 0, 'أرشيف ب فارغ');
    r = await J('GET', '/api/suggest?q=' + encodeURIComponent('مريض1'), A); ok(r.s === 200 && r.j.length >= 1 && r.j[0].birthYear === 1990 && r.j[0].phone === '0550000000', 'اقتراح مريض سابق مع الميلاد والهاتف');
    r = await J('GET', '/api/suggest?q=' + encodeURIComponent('مريض1'), B); ok(r.s === 200 && r.j.length === 0, 'الاقتراحات معزولة بين العيادات');
    r = await J('GET', '/api/suggest?q=' + encodeURIComponent('م'), A); ok(r.s === 200 && r.j.length === 0, 'حرف واحد لا يُقترح');
    r = await J('GET', '/api/suggest?q=abc'); ok(r.s === 401, 'الاقتراحات تتطلب دخولاً');
    r = await J('GET', '/api/suggest?q=' + encodeURIComponent('يض1'), A); ok(r.s === 200 && r.j.length === 0, 'الاقتراحات تطابق من بداية الاسم فقط');
    r = await J('PUT', '/api/prices', N, { currency: 'دج', list: { 'قلع': 1000 } }); ok(r.s === 403, 'الممرضة لا تعدّل الأسعار');
    r = await J('PUT', '/api/prices', A, { currency: 'دج', list: { 'قلع': '1500.505', 'غير معروف': 5, 'عصب': -1, 'أخرى': 'abc' } }); ok(r.s === 200 && r.j.currency === 'دج' && r.j.list['قلع'].base === 1500.51 && Object.values(r.j.list).filter(v => v.base != null).length === 1, 'حفظ الأسعار مع تنقية القيم غير الصالحة');
    r = await J('GET', '/api/state', A); ok(r.j.me.prices.list['قلع'].base === 1500.51, 'الطبيب يرى قائمة الأسعار');
    r = await J('GET', '/api/state', N); ok(r.j.me.prices === undefined, 'الممرضة لا ترى الأسعار');
    console.log('مهام الطبيب للممرضة (فقاعات)');
    { const code = (await J('GET', '/api/state', A)).j.me.code;
      await J('POST', '/api/nurses', A, { name: 'ممرضة ثانية', phone: '', password: 'nurse456' });
      const N2 = (await J('POST', '/api/login/nurse', null, { code, name: 'ممرضة ثانية', password: 'nurse456' })).j.token, n2id = (await J('GET', '/api/nurses', A)).j.find(z => z.name === 'ممرضة ثانية').id;
      let r = await J('POST', '/api/tasks', N, { text: 'x' }); ok(r.s === 403, 'الممرضة لا ترسل مهاماً');
      r = await J('POST', '/api/tasks', A, { text: '   ' }); ok(r.s === 400, 'رفض مهمة فارغة');
      r = await J('POST', '/api/tasks', A, { text: 'مهمة', to: 'ffffffffffff' }); ok(r.s === 404, 'رفض ممرضة غير موجودة');
      const nBefore = nEv.length;
      r = await J('POST', '/api/tasks', A, { text: 'جهّزي غرفة المعاينة', to: 'all' }); ok(r.s === 201 && r.j.id, 'الطبيب يرسل مهمة للجميع'); const tAll = r.j.id;
      r = await J('POST', '/api/tasks', A, { text: 'مهمة خاصة بالثانية', to: n2id }); ok(r.s === 201, 'مهمة موجّهة لممرضة محددة'); const tOne = r.j.id;
      await new Promise(z => setTimeout(z, 200));
      ok(nEv.slice(nBefore).some(([e, d]) => e === 'notify' && d.type === 'task' && d.text === 'جهّزي غرفة المعاينة') && !nEv.slice(nBefore).some(([e, d]) => e === 'notify' && d.text === 'مهمة خاصة بالثانية'), 'البث اللحظي: الممرضة تستلم مهمتها فقط');
      r = await J('GET', '/api/state', N); ok(r.j.tasks.length === 1 && r.j.tasks[0].text === 'جهّزي غرفة المعاينة' && !r.j.tasks[0].done, 'الممرضة ترى مهمتها فقط');
      r = await J('GET', '/api/state', N2); ok(r.j.tasks.length === 2, 'الممرضة الثانية ترى المهمتين');
      r = await J('GET', '/api/state', A); ok(r.j.tasks.length === 2, 'الطبيب يرى كل المهام');
      r = await J('GET', '/api/state', B); ok(r.j.tasks.length === 0, 'عيادة أخرى لا ترى المهام');
      r = await J('POST', `/api/tasks/${tOne}/done`, N); ok(r.s === 404, 'ممرضة لا تُنجز مهمة غير موجّهة لها');
      r = await J('POST', `/api/tasks/${tAll}/done`, B); ok(r.s === 404, 'عيادة أخرى لا تُنجز مهامنا');
      r = await J('DELETE', `/api/tasks/${tAll}`, N); ok(r.s === 403, 'الممرضة لا تحذف المهام');
      const dBefore = events.length;
      r = await J('POST', `/api/tasks/${tAll}/done`, N); ok(r.s === 200, 'الممرضة تُنجز المهمة');
      await new Promise(z => setTimeout(z, 200));
      ok(events.slice(dBefore).some(([e, d]) => e === 'notify' && d.type === 'task_done' && d.by), 'الطبيب يُبلَّغ بإنجاز المهمة');
      r = await J('GET', '/api/state', N); ok(r.j.tasks.length === 0, 'المهمة المنجزة تختفي من فقاعات الممرضة');
      r = await J('GET', '/api/state', N2); ok(r.j.tasks.length === 1 && r.j.tasks[0].id === tOne, 'وتختفي عند الممرضة الثانية أيضاً');
      r = await J('GET', '/api/state', A); const dn = r.j.tasks.find(z => z.id === tAll); ok(dn && dn.done && !!dn.doneBy, 'الطبيب يرى من أنجزها');
      r = await J('DELETE', `/api/tasks/${tOne}`, A); ok(r.s === 200, 'الطبيب يحذف مهمة معلّقة');
      r = await J('GET', '/api/state', N2); ok(r.j.tasks.length === 0, 'المهمة المحذوفة تختفي من الفقاعات');
      r = await J('POST', '/api/tasks', A, { text: 'z'.repeat(500) }); ok(r.s === 201 && (await J('GET', '/api/state', A)).j.tasks[0].text.length === 300, 'نص المهمة يُقصّ عند 300 حرف');  await J('DELETE', `/api/nurses/${n2id}`, A); for (const k of (await J('GET', '/api/state', A)).j.tasks) await J('DELETE', `/api/tasks/${k.id}`, A); }

    ac.abort(); acN.abort(); acT.abort();

    console.log('النسخ الاحتياطي والاستعادة والحذف');
    const bk = await (await fetch(base + '/api/backup', { headers: { Authorization: 'Bearer ' + A } })).json(); ok(bk.archive.length === 1 && Object.keys(bk.images).length === 1, 'تصدير نسخة احتياطية');
    r = await J('POST', '/api/restore', B, bk); ok(r.s === 200, 'استعادة في عيادة ب');
    const stB2 = (await J('GET', '/api/state', B)).j; ok(stB2.patients.every(x => x.ticket !== t3), 'رموز التذاكر لا تتكرر بين العيادات');
    r = await J('POST', '/api/clinic/wipe', A, { password: 'bad' }); ok(r.s === 401, 'المسح يتطلب كلمة المرور');
    const nid = (await J('GET', '/api/nurses', A)).j[0].id; r = await J('DELETE', '/api/nurses/' + nid, A); ok(r.s === 200, 'حذف الممرضة');
    r = await J('GET', '/api/state', N); ok(r.s === 401, 'جلسة الممرضة المحذوفة تُلغى');
    r = await J('POST', '/api/clinic/wipe', A, { password: 'password1', account: true }); ok(r.s === 200, 'حذف حساب الطبيب أ');
    r = await J('GET', `/api/ticket/${t3}`); ok(r.s === 404, 'تذاكر العيادة المحذوفة تصبح غير صالحة');
    r = await J('GET', '/api/state', B); ok(r.s === 200, 'عيادة ب لم تتأثر');

    console.log('أوقات وأيام تسجيل الممرضة');
    r = await J('POST', '/api/nurses', B, { name: 'نورة', phone: '0771', password: 'nurse456' }); ok(r.s === 201, 'إضافة ممرضة لعيادة ب');
    r = await J('POST', '/api/login/nurse', null, { code: meB.code, name: 'نورة', password: 'nurse456' }); const NB = r.j.token;
    r = await J('GET', '/api/state', NB); ok(r.j.schedule && r.j.schedule.enabled === false, 'التقييد متوقف افتراضياً');
    r = await J('POST', '/api/patients', NB, pat('م-مفتوح')); ok(r.s === 201, 'التسجيل مسموح عند إيقاف التقييد');
    { const d = new Date(), today = d.getUTCDay(), mins = d.getUTCHours() * 60 + d.getUTCMinutes();
      const sch = o => ({ enabled: true, days: [0, 1, 2, 3, 4, 5, 6], from: '00:00', to: '23:59', tz: 0, ...o });
      r = await J('PUT', '/api/schedule', NB, sch()); ok(r.s === 403, 'الممرضة لا تغيّر الجدول');
      r = await J('PUT', '/api/schedule', B, sch({ from: '10:00', to: '09:00' })); ok(r.s === 400, 'رفض وقت نهاية قبل البداية');
      r = await J('PUT', '/api/schedule', B, sch({ days: [] })); ok(r.s === 400, 'رفض تفعيل بلا أيام');
      r = await J('PUT', '/api/schedule', B, sch({ from: '25:00' })); ok(r.s === 400, 'رفض وقت غير صالح');
      r = await J('PUT', '/api/schedule', B, sch({ days: [0, 1, 2, 3, 4, 5, 6].filter(x => x !== today) })); ok(r.s === 200, 'الطبيب يحفظ جدولاً بدون اليوم');
      r = await J('POST', '/api/patients', NB, pat('م-يوم مغلق')); ok(r.s === 403, 'الممرضة ممنوعة في يوم غير مسموح');
      r = await J('POST', '/api/patients', B, pat('م-الطبيب')); ok(r.s === 201, 'الطبيب يسجّل دائماً رغم التقييد');
      r = await J('GET', '/api/state', NB); ok(r.j.schedule.enabled === true && !r.j.schedule.days.includes(today), 'الممرضة ترى الجدول في الحالة');
      r = await J('PUT', '/api/schedule', B, sch({ days: [today], ...(mins >= 720 ? { from: '00:00', to: '06:00' } : { from: '18:00', to: '23:00' }) })); ok(r.s === 200, 'جدول اليوم لكن خارج الساعات');
      r = await J('POST', '/api/patients', NB, pat('م-خارج الوقت')); ok(r.s === 403, 'الممرضة ممنوعة خارج الساعات');
      r = await J('PUT', '/api/schedule', B, sch({ days: [today], from: '00:00', to: '23:59', tz: 0 })); ok(r.s === 200, 'جدول اليوم طوال اليوم');
      if (mins < 23 * 60 + 59) { r = await J('POST', '/api/patients', NB, pat('م-داخل الوقت')); ok(r.s === 201, 'الممرضة تسجّل داخل الأيام والساعات'); }
      r = await J('PUT', '/api/schedule', B, sch({ enabled: false })); ok(r.s === 200, 'إيقاف التقييد'); r = await J('POST', '/api/patients', NB, pat('م-بعد الإيقاف')); ok(r.s === 201, 'التسجيل يعود مفتوحاً'); }

    console.log('الحساب المالي والدفع على دفعات');
    r = await J('PUT', '/api/prices', B, { currency: 'دج', list: { 'علاج عصب': { base: 3000, front: 2500, pre: 3500, molar: 5000, bad: 9 } } }); ok(r.s === 200 && r.j.list['علاج عصب'].molar === 5000 && r.j.list['علاج عصب'].bad === undefined, 'أسعار حسب نوع السن');
    { const st = (await J('GET', '/api/state', B)).j; const inRoom = st.patients.find(z => z.status === 'in'); if (inRoom) await J('POST', `/api/patients/${inRoom.id}/finish`, B, { treatment: 'x' });
      const mk = async () => { const q = await J('POST', '/api/patients', B, pat('مريض مالي', { birthYear: 1985 })); const e = await J('POST', `/api/patients/${q.j.id}/enter`, B); return q.j.id; };
      let id = await mk();
      r = await J('POST', `/api/patients/${id}/finish`, B, { treatment: 'علاج عصب', teeth: ['16'], price: 5000, paid: 2000 }); ok(r.s === 200 && r.j.paid === 2000 && r.j.remaining === 3000, 'زيارة أولى: مستحق 5000 ومدفوع 2000');
      r = await J('GET', '/api/account?name=' + encodeURIComponent('مريض مالي') + '&year=1985', B); ok(r.j.balance === 3000 && r.j.due === 5000 && r.j.paid === 2000 && r.j.records.length === 1, 'حساب المريض: المتبقي 3000');
      r = await J('GET', '/api/account?name=x&year=1985', N); ok(r.s === 401 || r.s === 403, 'الحساب للطبيب فقط');
      id = await mk();
      r = await J('POST', `/api/patients/${id}/finish`, B, { treatment: 'علاج عصب', teeth: ['16'], price: 0, paid: 1000, followUp: true }); ok(r.s === 200 && r.j.paid === 0 && r.j.followUp === true, 'حصة متابعة بلا سعر جديد');
      r = await J('GET', '/api/account?name=' + encodeURIComponent('مريض مالي') + '&year=1985', B); ok(r.j.balance === 2000 && r.j.paid === 3000, 'الدفعة الثانية تسدّد الأقدم: المتبقي 2000');
      const rec = r.j.records.find(z => z.remaining > 0); r = await J('POST', `/api/archive/${rec.id}/payment`, B, { amount: 5000 }); ok(r.s === 200 && r.j.remaining === 0 && r.j.paid === 5000 && r.j.payments.length === 3, 'دفعة مباشرة تُقصّ عند المتبقي');
      r = await J('POST', `/api/archive/${rec.id}/payment`, B, { amount: 10 }); ok(r.s === 409, 'لا دفعة على سجل مسدَّد');
      r = await J('GET', '/api/archive?name=' + encodeURIComponent('مريض مالي'), B); ok(r.j.sum === 5000 && r.j.paidSum === 5000 && r.j.debt === 0, 'إجماليات الأرشيف: مستحق/محصَّل/متبقٍ'); }

    console.log('وعاء المريض وسجل الدفعات');
    { const NM = 'مريض الوعاء', YR = 1991, q = encodeURIComponent(NM);
      const fin = async body => { const p0 = (await J('POST', '/api/patients', B, pat(NM, { birthYear: YR }))).j; await J('POST', `/api/patients/${p0.id}/enter`, B); const r = await J('POST', `/api/patients/${p0.id}/finish`, B, { treatment: 'علاج عصب', teeth: ['16'], ...body }); return { id: p0.id, r }; };
      const wal = async () => (await J('GET', `/api/account?name=${q}&year=${YR}`, B)).j.wallet;
      let r = await J('POST', '/api/wallet', B, { name: NM, year: YR, amount: 3000 }); ok(r.s === 200 && r.j.bal === 3000 && r.j.log.length === 1, 'إيداع 3000 في الوعاء');
      r = await J('POST', '/api/wallet', B, { name: NM, year: YR, amount: -5 }); ok(r.s === 400, 'إيداع غير صالح مرفوض');
      r = await J('POST', '/api/wallet', N, { name: NM, year: YR, amount: 10 }); ok(r.s === 401 || r.s === 403, 'الوعاء للطبيب فقط');
      ok(await wal() === 3000, 'الحساب يعرض رصيد الوعاء');
      /* حصة أولى: علاج 5000 يُسدَّد 3000 من الوعاء + 1000 نقداً */
      const v1 = await fin({ price: 5000, paid: 1000, wallet: 3000 }); ok(v1.r.s === 200 && v1.r.j.paid === 4000 && v1.r.j.remaining === 1000, 'الحصة الأولى: 3000 من الوعاء + 1000 نقداً');
      const pw = v1.r.j.payments.find(p => p.m === 'w'), pc = v1.r.j.payments.find(p => !p.m);
      ok(pw && pw.amt === 3000 && pw.vid === v1.id && pw.vn === 1 && pc && pc.amt === 1000, 'كل دفعة تحمل الحصة التي دُفعت فيها ونوعها (وعاء/نقد)');
      ok(await wal() === 0, 'الوعاء بعد الاقتطاع = 0');
      /* حصة ثانية (متابعة): دفع 1000 نقداً يسدّد باقي الحصة الأولى ويُسجَّل أنه دُفع في الحصة 2 */
      const v2 = await fin({ price: 0, paid: 1500, followUp: true }); ok(v2.r.s === 200 && v2.r.j.paid === 0, 'حصة المتابعة بلا سعر');
      r = await J('GET', `/api/history?name=${q}&year=${YR}`, B); const h = r.j, a1 = h.records.find(z => z.id === v1.id);
      ok(h.balance === 0 && a1.remaining === 0 && a1.n === 1, 'السجل الأول سُدّد بالكامل');
      const late = a1.payments.find(p => p.vid === v2.id); ok(late && late.amt === 1000 && late.vn === 2 && late.vat, 'الدفعة المتأخرة تُنسب للحصة 2');
      ok(h.wallet.bal === 500 && h.wallet.log.some(e => e.k === 'dep' && e.amt === 500 && e.vid === v2.id), 'الفائض النقدي (500) أُودع في الوعاء');
      /* دين جديد يُسدَّد من الوعاء مباشرة من الأرشيف */
      const v3 = await fin({ price: 2000, paid: 0 }); ok(v3.r.j.remaining === 2000, 'حصة ثالثة غير مدفوعة');
      r = await J('POST', `/api/archive/${v3.id}/payment`, B, { amount: 9999, wallet: true }); ok(r.s === 200 && r.j.paid === 500 && r.j.payments[0].m === 'w' && r.j.payments[0].vid === null, 'دفعة من الوعاء تُقصّ عند رصيده');
      ok(await wal() === 0, 'الوعاء فرغ'); r = await J('POST', `/api/archive/${v3.id}/payment`, B, { amount: 10, wallet: true }); ok(r.s === 409, 'لا دفعة من وعاء فارغ');
      /* الإحصائيات: المقتطع من الوعاء لا يُحسب مرتين */
      const bk = (await J('GET', '/api/backup', B)).j; let exp = 0;
      for (const rec of bk.archive) for (const p of rec.payments || []) if (p.m !== 'w') exp += p.amt;
      for (const w of Object.values(bk.wallets)) for (const e of w.log) exp += e.k === 'dep' ? e.amt : e.k === 'out' ? -e.amt : 0;
      r = await J('GET', '/api/stats?tz=0', B); ok(Math.abs(r.j.summary.collected - exp) < 0.01, 'المحصَّل = نقد الحصص + إيداعات الوعاء (دون اقتطاعاته)');
      /* النسخ الاحتياطي يحفظ الوعاء */
      await J('POST', '/api/wallet', B, { name: NM, year: YR, amount: 700 });
      const bk2 = (await J('GET', '/api/backup', B)).j; ok(Object.values(bk2.wallets).some(w => w.bal === 700), 'النسخة الاحتياطية تشمل الوعاء');
      r = await J('POST', '/api/restore', B, bk2); ok(r.s === 200 && await wal() === 700, 'الاستعادة تعيد الوعاء');
      r = await J('GET', `/api/history?name=${q}&year=${YR}`, B); ok(r.j.records.some(z => z.payments.some(p => p.m === 'w' && p.vn)), 'الاستعادة تحفظ نوع الدفعة ورقم الحصة');
      /* استرجاع نقدي + حذف سجل دُفع من الوعاء يعيد المبلغ */
      r = await J('POST', '/api/wallet', B, { name: NM, year: YR, amount: 5000, op: 'out' }); ok(r.s === 409, 'لا استرجاع أكثر من الرصيد');
      r = await J('POST', '/api/wallet', B, { name: NM, year: YR, amount: 200, op: 'out' }); ok(r.s === 200 && r.j.bal === 500, 'استرجاع نقدي 200');
      r = await J('DELETE', `/api/archive/${v3.id}`, B); ok(r.s === 200 && await wal() === 1000, 'حذف سجل دُفع من الوعاء يعيد 500 إليه'); }

    console.log('خطة العلاج لكل سن (حصة أو حصتان)');
    { const NM = 'مريض الخطة', YR = 1980, q = encodeURIComponent(NM);
      const vis = async (body) => { const rm = (await J('GET', '/api/state', B)).j.patients.find(z => z.status === 'in'); if (rm) await J('POST', `/api/patients/${rm.id}/finish`, B, { lines: [] }); const p0 = (await J('POST', '/api/patients', B, pat(NM, { birthYear: YR }))).j; await J('POST', `/api/patients/${p0.id}/enter`, B); const r = await J('POST', `/api/patients/${p0.id}/finish`, B, body); return r; };
      const acct = async () => (await J('GET', `/api/account?name=${q}&year=${YR}`, B)).j;
      let r = await vis({ lines: [{ tooth: '16', treatment: 'علاج عصب', total: 6000, sessions: 2, pay: 3000 }] });
      ok(r.s === 200 && r.j.price === 6000 && r.j.paid === 3000 && r.j.remaining === 3000 && r.j.lines.length === 1 && r.j.lines[0].no === 1 && r.j.lines[0].sessions === 2 && r.j.teeth[0] === '16', 'الحصة 1: سعر كلي 6000 ودفع نصفه');
      const rec1 = r.j.id, plan = r.j.lines[0].plan;
      let a = await acct(); ok(a.plans.length === 1 && a.plans[0].tooth === '16' && a.plans[0].remaining === 3000 && a.plans[0].done === 1 && a.plans[0].open && a.debts.length === 0 && a.balance === 3000, 'الخطة الجارية تظهر مع متبقّيها (لا تُعدّ ديناً منفصلاً)');
      r = await vis({ lines: [{ plan, pay: 99999 }] });
      ok(r.s === 200 && r.j.price === 0 && r.j.paid === 0 && r.j.followUp === true && r.j.lines[0].no === 2 && r.j.lines[0].remaining === 0 && r.j.lines[0].open === false && r.j.treatment === 'علاج عصب' && r.j.teeth[0] === '16', 'الحصة 2: تُسدَّد بقية الخطة والزائد يُقصّ');
      const rec2 = r.j.id; a = await acct(); ok(a.plans.length === 0 && a.balance === 0, 'اكتملت الخطة ولا متبقٍ');
      r = await J('GET', `/api/history?name=${q}&year=${YR}`, B); const h1 = r.j.records.find(z => z.id === rec1);
      ok(h1.paid === 6000 && h1.payments.length === 2 && h1.payments[1].vid === rec2 && h1.payments[1].vn === 2 && h1.payments.every(p => p.pl === undefined || true), 'دفعة الحصة 2 تُسجَّل على سجل الحصة 1 وتُنسب للحصة 2');
      r = await vis({ lines: [{ plan, pay: 10 }] }); ok(r.s === 409, 'لا متابعة لخطة مكتملة');
      r = await vis({ lines: [{ plan: 'aaaaaaaaaa', pay: 10 }] }); ok(r.s === 404, 'خطة غير موجودة');
      r = await vis({ lines: [{ tooth: '99', treatment: 'قلع', total: 1 }] }); ok(r.s === 400, 'سن غير صالح');
      /* حصة واحدة تُدفع كاملة + بندان في زيارة واحدة */
      r = await vis({ lines: [{ tooth: '26', treatment: 'حشوة', total: 1500, sessions: 1, pay: 1500 }, { tooth: '27', treatment: 'علاج عصب', total: 4000, sessions: 2, pay: 1000 }] });
      ok(r.s === 200 && r.j.price === 5500 && r.j.paid === 2500 && r.j.remaining === 3000 && r.j.treatments.length === 2 && r.j.teeth.length === 2 && r.j.lines.find(l => l.tooth === '27').remaining === 3000 && r.j.lines.find(l => l.tooth === '26').open === false, 'بندان: حشوة بحصة (مدفوعة) وعصب بحصتين');
      const rec3 = r.j.id, plan27 = r.j.lines.find(l => l.tooth === '27').plan; a = await acct(); ok(a.plans.length === 1 && a.plans[0].tooth === '27' && a.balance === 3000, 'الخطة المفتوحة الوحيدة هي السن 27');
      /* الوعاء: يغطّي جزءاً من الدفع والباقي نقداً */
      await J('POST', '/api/wallet', B, { name: NM, year: YR, amount: 1000 });
      r = await vis({ lines: [{ plan: plan27, pay: 2000 }], wallet: 5000 });
      ok(r.s === 200 && (await acct()).wallet === 0 && (await acct()).balance === 1000, 'الاقتطاع من الوعاء لا يتجاوز رصيده (1000) وتُسدَّد 2000');
      const rec4 = r.j.id; r = await J('GET', `/api/history?name=${q}&year=${YR}`, B); const h3 = r.j.records.find(z => z.id === rec3);
      ok(h3.payments.filter(p => p.vid === rec4).length === 2 && h3.payments.filter(p => p.vid === rec4 && p.m === 'w').reduce((x, p) => x + p.amt, 0) === 1000, 'دفعتان: 1000 من الوعاء و1000 نقداً');
      a = await acct(); ok(a.plans.length === 0 && a.debts.length === 1 && a.debts[0].plan === plan27 && a.debts[0].remaining === 1000, 'الخطة اكتملت بحصصها وبقي 1000 ديناً قابلاً للسداد');
      /* حذف الحصة 2 يعيد الخطة مفتوحة ويعيد الوعاء */
      r = await J('DELETE', `/api/archive/${rec4}`, B); ok(r.s === 200, 'حذف حصة المتابعة');
      a = await acct(); ok(a.wallet === 1000 && a.plans.length === 1 && a.plans[0].remaining === 3000 && a.plans[0].done === 1 && a.balance === 3000, 'الحذف يلغي دفعاتها ويعيد الخطة مفتوحة والوعاء');
      /* إغلاق خطة قبل اكتمالها + سداد بالدَّين بلا حصة علاجية */
      r = await J('POST', `/api/plans/${plan27}/close`, B); ok(r.s === 200, 'إغلاق الخطة'); r = await J('POST', `/api/plans/${plan27}/close`, N); ok(r.s === 401 || r.s === 403, 'الإغلاق للطبيب فقط');
      a = await acct(); ok(a.plans.length === 0 && a.debts.length === 1 && a.debts[0].remaining === 3000, 'الخطة المغلقة تتحوّل إلى دَين');
      r = await vis({ lines: [], debts: [{ plan: plan27, pay: 500 }] }); ok(r.s === 200 && r.j.price === 0 && r.j.followUp === true && (await acct()).balance === 2500, 'سداد دفعة من الدَّين بزيارة بلا علاج');
      r = await vis({ lines: [], debts: [{ rec: 'f'.repeat(12), pay: 5 }] }); ok(r.s === 404, 'سجل دَين غير موجود');
      /* تعديل سجل الخطة يدوياً يطابق البنود والدفعات */
      r = await J('PUT', `/api/archive/${rec3}`, B, { name: NM, birthYear: YR, gender: 'ذكر', reason: 'قلع أسنان', tooth: '26 27', price: 5500, paid: 5500, treatments: ['حشوة', 'علاج عصب'] });
      ok(r.s === 200 && r.j.remaining === 0, 'تعديل المدفوع إلى الكل'); a = await acct(); ok(a.debts.length === 0 && a.plans.length === 0 && a.balance === 0, 'بعد التعديل: لا خطط ولا ديون');
      /* سداد من الأرشيف على سجل له خطة: يُنسب للخطة ويُقصّ عند متبقّيها والزائد يذهب للوعاء */
      r = await vis({ lines: [{ tooth: '36', treatment: 'علاج عصب', total: 3000, sessions: 2, pay: 1000 }] }); const rec5 = r.j.id, plan36 = r.j.lines[0].plan;
      const w0 = (await acct()).wallet; r = await J('POST', `/api/archive/${rec5}/payment`, B, { amount: 500 }); ok(r.s === 200 && r.j.paid === 1500 && r.j.lines[0].remaining === 1500, 'دفعة أرشيف تُنسب إلى الخطة');
      r = await J('POST', `/api/archive/${rec5}/payment`, B, { amount: 2000 }); a = await acct(); ok(r.s === 200 && r.j.remaining === 0 && a.wallet === w0 + 500 && a.plans.some(p => p.id === plan36 && p.remaining === 0 && p.open), 'الزائد عن الخطة يُودَع في الوعاء والخطة تبقى مفتوحة للحصة الثانية');
      r = await vis({ lines: [{ plan: plan36, pay: 0 }] }); ok(r.s === 200 && r.j.lines[0].no === 2 && r.j.paid === 0 && (await acct()).plans.length === 0, 'الحصة الثانية بلا دفع إضافي تُكمل الخطة');
      /* علاج بثلاث حصص + إضافة حصة أثناء العلاج + ضبط عدد الحصص في قائمة الأسعار */
      r = await vis({ lines: [{ tooth: '46', treatment: 'تقويم', total: 3000, sessions: 3, pay: 1000 }] }); const plan46 = r.j.lines[0].plan;
      ok(r.s === 200 && r.j.lines[0].sessions === 3 && r.j.remaining === 2000, 'خطة بثلاث حصص');
      r = await vis({ lines: [{ plan: plan46, pay: 1000 }] }); ok(r.s === 200 && r.j.lines[0].no === 2 && (await acct()).plans.some(p => p.id === plan46 && p.open && p.remaining === 1000), 'الحصة 2 من 3 تبقي الخطة مفتوحة');
      r = await J('POST', `/api/plans/${plan46}/sessions`, B, { delta: 1 }); ok(r.s === 200 && r.j.sessions === 4, 'إضافة حصة (4)'); r = await J('POST', `/api/plans/${plan46}/sessions`, N, { delta: 1 }); ok(r.s === 401 || r.s === 403, 'الإضافة للطبيب فقط');
      r = await vis({ lines: [{ plan: plan46, pay: 0 }] }); ok(r.s === 200 && r.j.lines[0].no === 3 && r.j.lines[0].sessions === 4 && (await acct()).plans.some(p => p.id === plan46 && p.open), 'الحصة 3 من 4 ما زالت مفتوحة بعد الإضافة');
      r = await vis({ lines: [{ plan: plan46, pay: 1000 }] }); ok(r.s === 200 && r.j.lines[0].no === 4 && (await acct()).plans.length === 0, 'الحصة 4 تُكمل الخطة');
      r = await J('POST', `/api/plans/aaaaaaaaaa/sessions`, B, { delta: 1 }); ok(r.s === 404, 'خطة غير موجودة');
      r = await vis({ lines: [{ tooth: '47', treatment: 'تقويم', total: 0, sessions: 99, pay: 0 }] }); ok(r.s === 200 && r.j.lines[0].sessions === 1, 'عدد حصص غير صالح يصير 1'); await J('POST', `/api/plans/${r.j.lines[0].plan}/close`, B);
      r = await J('PUT', '/api/prices', B, { currency: 'DA', treatments: ['حشوة', 'علاج عصب', 'تقويم'], list: { 'حشوة': { base: 1500, sessions: 1 }, 'علاج عصب': { base: 6000, sessions: 3 }, 'تقويم': { sessions: 99 } } });
      ok(r.s === 200 && r.j.list['علاج عصب'].sessions === 3 && r.j.list['حشوة'].sessions === 1 && r.j.list['تقويم'].sessions === 1 && r.j.list['علاج عصب'].base === 6000, 'قائمة الحصص والأسعار تحفظ عدد الحصص لكل علاج');
      r = await J('PUT', '/api/prices', B, { currency: 'DA', treatments: ['قلع', 'علاج عصب', 'استشارة'], list: { 'قلع': { base: 500, col: { on: true, part: '#FF0000', done: 'bad' } }, 'علاج عصب': { base: 6000, sessions: 2, col: { on: true, part: '#f2b705', done: '#2e9e6b' } } } });
      ok(r.s === 200 && r.j.list['قلع'].col.part === '#ff0000' && r.j.list['قلع'].col.done === '#d64545' && r.j.list['علاج عصب'].col.done === '#2e9e6b' && r.j.list['استشارة'].col.on === false, 'ألوان العلاجات تُحفظ وتُنقّى وفيها افتراضات');
      r = await vis({ lines: [{ tooth: '15', treatment: 'علاج عصب', total: 0, sessions: 2, pay: 0 }, { tooth: '16', treatment: 'قلع', total: 0, sessions: 1, pay: 0 }] });
      a = await acct(); ok(Array.isArray(a.teeth) && a.teeth.some(z => z.tooth === '15' && z.treatment === 'علاج عصب' && z.no === 1 && z.sessions === 2) && a.teeth.some(z => z.tooth === '16' && z.treatment === 'قلع'), 'حساب المريض يعيد حالة الأسنان لمخطط المعاينة');
      await J('POST', `/api/plans/${r.j.lines[0].plan}/close`, B);
      /* فلتر الأرشيف: المدينون والدائنون */
      await J('POST', '/api/wallet', B, { name: NM, year: YR, amount: 700 });
      r = await J('GET', '/api/archive?money=creditors', B); ok(r.s === 200 && r.j.walSum >= 700 && r.j.items.length >= 1 && r.j.items.every(z => z.wallet > 0) && new Set(r.j.items.map(z => z.name + z.birthYear)).size === r.j.items.length, 'فلتر الدائنين: سجل واحد لكل مريض لديه رصيد');
      r = await J('GET', '/api/archive?money=debtors', B); ok(r.s === 200 && r.j.items.every(z => z.remaining > 0) && r.j.total === r.j.items.length, 'فلتر المدينين: سجلات عليها متبقٍّ فقط');
      /* نسخة احتياطية واستعادة تحفظ البنود وانتساب الدفعات */
      const bk = (await J('GET', '/api/backup', B)).j; ok(bk.archive.some(z => z.lines && z.lines.length) && bk.archive.some(z => (z.payments || []).some(p => p.pl)), 'النسخة تشمل بنود الخطط');
      ok(bk.version === 3 && 'schedule' in bk && Array.isArray(bk.nurses) && typeof bk.protect === 'boolean' && 'counter' in bk && bk.nurses.every(n => n.hash && n.salt), 'النسخة تشمل الجدول وحسابات الممرضات وحماية الأرشيف والعدّاد');
      const nn0 = (await J('GET', '/api/nurses', B)).j.length;
      r = await J('POST', '/api/restore', B, bk); ok(r.s === 200, 'استعادة');
      ok((await J('GET', '/api/nurses', B)).j.length === nn0, 'الاستعادة لا تكرّر حسابات الممرضات الموجودة'); r = await J('GET', `/api/history?name=${q}&year=${YR}`, B); ok(r.j.records.some(z => z.lines.length && z.lines[0].plan) && r.j.balance === 0, 'الاستعادة تحفظ البنود');
      const rm = (await J('GET', '/api/state', B)).j.patients.find(z => z.status === 'in'); if (rm) await J('POST', `/api/patients/${rm.id}/finish`, B, { lines: [] }); }

    console.log('علم المتبقي على المريض');
    { const A = B;   /* عيادة أ حُذفت أعلاه؛ نستعمل عيادة ب (حد التسجيل 10/ساعة) */
      const dcode = (await J('GET', '/api/state', A)).j.me.code; await J('POST', '/api/nurses', A, { name: 'ممرضة د', phone: '2', password: 'nurse888' });
      const N = (await J('POST', '/api/login/nurse', null, { code: dcode, name: 'ممرضة د', password: 'nurse888' })).j.token;
      const NM = 'مريض مدين', YR = 1985, mk = async () => (await J('POST', '/api/patients', A, pat(NM, { birthYear: YR }))).j;
      const p0 = await mk(); await J('POST', `/api/patients/${p0.id}/enter`, A); await J('POST', `/api/patients/${p0.id}/finish`, A, { treatment: 'حشوة', price: 1000, paid: 400 });
      const p1 = await mk();
      r = await J('GET', '/api/state', A); ok(r.j.patients.find(z => z.id === p1.id).debt === 600, 'الطبيب يرى متبقي المريض في الطابور');
      r = await J('GET', '/api/state', N); ok(r.j.patients.every(z => z.debt === undefined), 'الممرضة لا ترى أي مبالغ'); }

    console.log('إدارة العلاجات والأسعار');
    { const D = (await J('POST', '/api/register', null, { clinicName: 'عيادة علاج', doctorName: 'د. ع', username: 'treatdoc', password: 'password7' })).j.token;
      r = await J('GET', '/api/state', D); ok(r.j.me.prices.treatments.length === 6 && r.j.me.prices.treatments[0] === 'قلع', 'القائمة الافتراضية 6 علاجات');
      r = await J('PUT', '/api/prices', D, { currency: 'دج', treatments: ['قلع', 'تنظيف الجير', 'حشوة تجميلية'], list: { 'قلع': 1000, 'تنظيف الجير': { base: 2500 }, 'حشوة تجميلية': { front: 4000, molar: 6000 }, 'محذوف': 5 } });
      ok(r.s === 200 && r.j.treatments.join('|') === 'قلع|تنظيف الجير|حشوة تجميلية' && r.j.list['تنظيف الجير'].base === 2500 && r.j.list['حشوة تجميلية'].molar === 6000 && !r.j.list['محذوف'], 'إضافة علاجات مخصّصة وحذف الباقي مع أسعارها');
      r = await J('GET', '/api/state', D); ok(r.j.me.prices.treatments.length === 3 && r.j.me.prices.list['قلع'].base === 1000, 'التعديل يُحفظ ويُرجَع في الحالة');
      r = await J('PUT', '/api/prices', D, { currency: 'دج', treatments: ['قلع', ' قلع '], list: {} }); ok(r.s === 400, 'رفض اسم مكرر');
      r = await J('PUT', '/api/prices', D, { currency: 'دج', treatments: ['A', 'a'], list: {} }); ok(r.s === 400, 'رفض مكرر بلا حساسية للحالة');
      r = await J('PUT', '/api/prices', D, { currency: 'دج', treatments: [], list: {} }); ok(r.s === 400, 'يجب بقاء علاج واحد على الأقل');
      r = await J('PUT', '/api/prices', D, { currency: 'دج', treatments: ['x'.repeat(41)], list: {} }); ok(r.s === 400, 'رفض اسم أطول من 40');
      r = await J('PUT', '/api/prices', D, { currency: 'دج', treatments: ['__proto__'], list: {} }); ok(r.s === 400, 'رفض اسم خطِر');
      r = await J('PUT', '/api/prices', D, { currency: 'دج', treatments: Array.from({ length: 31 }, (_, i) => 'علاج' + i), list: {} }); ok(r.s === 400, 'حدّ 30 علاجاً');
      r = await J('PUT', '/api/prices', D, { currency: '$', list: { 'قلع': 1200 } }); ok(r.s === 200 && r.j.treatments.length === 3 && r.j.list['قلع'].base === 1200, 'طلب بلا قائمة علاجات يُبقي القائمة الحالية');
      r = await J('PUT', '/api/prices', D, { currency: '$', list: { 'قلع': { base: 1000, molar: 1500, wisdom: 2500 } } }); ok(r.s === 200 && r.j.list['قلع'].wisdom === 2500 && r.j.list['قلع'].molar === 1500, 'حفظ سعر ضرس العقل ضمن الأسعار');
      const tp = (await J('POST', '/api/patients', D, pat('مريض علاج'))).j; await J('POST', `/api/patients/${tp.id}/enter`, D);
      r = await J('POST', `/api/patients/${tp.id}/finish`, D, { treatment: 'حشوة تجميلية', price: 4000 }); ok(r.s === 200 && r.j.treatment === 'حشوة تجميلية', 'إنهاء المعاينة بعلاج مخصّص');
      r = await J('GET', '/api/archive?treatment=' + encodeURIComponent('حشوة'), D); ok(r.j.items.length === 1, 'فلترة الأرشيف بالعلاج المخصّص'); 
      { const mp = (await J('POST', '/api/patients', D, pat('مريض متعدد'))).j; await J('POST', `/api/patients/${mp.id}/enter`, D);
        r = await J('POST', `/api/patients/${mp.id}/finish`, D, { treatment: 'x', treatments: ['قلع', 'تنظيف الجير', 'قلع', '', 'حشوة تجميلية'], items: [{ name: 'قلع', price: 1200 }, { name: 'تنظيف الجير', price: 2500 }, { name: 'حشوة تجميلية', price: 4000 }], price: 7700, paid: 5000 });
        ok(r.s === 200 && r.j.treatments.join('|') === 'قلع|تنظيف الجير|حشوة تجميلية' && r.j.treatment === 'قلع + تنظيف الجير + حشوة تجميلية' && r.j.price === 7700 && r.j.remaining === 2700 && r.j.items.length === 3, 'إنهاء المعاينة بعدة علاجات مع تنظيف التكرار وحفظ البنود');
        r = await J('GET', '/api/archive?treatment=' + encodeURIComponent('تنظيف'), D); ok(r.j.items.some(z => z.name === 'مريض متعدد'), 'فلترة الأرشيف تجد الزيارة متعددة العلاجات');
        r = await J('GET', '/api/stats?tz=0', D); const tt = r.j.treatments, sum = k => Math.round(tt.reduce((x, y) => x + y[k], 0) * 100) / 100, g = n => tt.find(z => z.name === n);
        ok(g('تنظيف الجير') && g('قلع') && g('حشوة تجميلية') && Math.abs(g('حشوة تجميلية').billed - 8000) < 0.01 && Math.abs(g('تنظيف الجير').billed - 2500) < 0.01, 'الإحصائيات توزّع مستحق الزيارة المتعددة على علاجاتها بنسبة أسعارها'); } }

    console.log('إشعارات النظام (Web Push)');
    { /* عيادة جديدة نظيفة لهذا القسم */
      const A = (await J('POST', '/api/register', null, { clinicName: 'عيادة الدفع', doctorName: 'د. دفع', username: 'pushdoc', password: 'password9' })).j.token;
      const pc = (await J('GET', '/api/state', A)).j.me.code; await J('POST', '/api/nurses', A, { name: 'ممرضة', phone: '1', password: 'nurse999' });
      const N = (await J('POST', '/api/login/nurse', null, { code: pc, name: 'ممرضة', password: 'nurse999' })).j.token;
      const pk = (await J('GET', '/api/push/key', A)).j.key; ok(Buffer.from(pk, 'base64url').length === 65, 'مفتاح VAPID العام (65 بايت)');
      r = await J('GET', '/api/push/key'); ok(r.s === 401, 'المفتاح يتطلب تسجيل دخول');
      r = await J('POST', '/api/push/subscribe', A, { subscription: { endpoint: 'https://evil.example.com/x', keys: { p256dh: mkSub('/x').sub.keys.p256dh, auth: mkSub('/x').sub.keys.auth } } }); ok(r.s === 400, 'رفض نقطة نهاية خارج خدمات الدفع المعروفة');
      r = await J('POST', '/api/push/subscribe', A, { subscription: { endpoint: 'http://127.0.0.1:9/x', keys: mkSub('/x').sub.keys } }); ok(r.s === 400, 'رفض عنوان داخلي (SSRF)');
      r = await J('POST', '/api/push/subscribe', A, { subscription: { endpoint: mkSub('/x').sub.endpoint, keys: { p256dh: 'AAAA', auth: 'AAAA' } } }); ok(r.s === 400, 'رفض مفاتيح غير صالحة');
      const D = mkSub('/doctor'), NU = mkSub('/nurse');
      r = await J('POST', '/api/push/subscribe', A, { subscription: D.sub, lang: 'ar' }); ok(r.s === 200, 'اشتراك الطبيب');
      r = await J('POST', '/api/push/subscribe', N, { subscription: NU.sub, lang: 'en' }); ok(r.s === 200, 'اشتراك الممرضة');
      const got = async (p, n = 1) => { for (let i = 0; i < 40; i++) { const f = pushes.filter(z => z.url === p); if (f.length >= n) return f; await wait(50); } return []; };
      pushes.length = 0;
      const np = (await J('POST', '/api/patients', N, pat('مريض الدفع'))).j;
      let g = await got('/doctor'); ok(g.length === 1, 'الطبيب يستلم دفعاً عند تسجيل مريض');
      const m1 = decryptPush(g[0].body, D.e, D.auth); ok(m1.title.includes('مريض جديد') && m1.body.includes('مريض الدفع') && m1.urgent === true, 'الحمولة تُفكّ وتحوي اسم المريض (تشفير صحيح)');
      ok(g[0].headers.urgency === 'high' && g[0].headers['content-encoding'] === 'aes128gcm' && +g[0].headers.ttl > 0, 'أولوية عالية + aes128gcm + TTL');
      { const [, t64] = /t=([^,]+)/.exec(g[0].headers.authorization), [h, b2, sg] = t64.split('.'), pub = Buffer.from(pk, 'base64url');
        const key = crypto.createPublicKey({ key: { kty: 'EC', crv: 'P-256', x: pub.subarray(1, 33).toString('base64url'), y: pub.subarray(33).toString('base64url') }, format: 'jwk' });
        ok(crypto.verify('sha256', Buffer.from(h + '.' + b2), { key, dsaEncoding: 'ieee-p1363' }, Buffer.from(sg, 'base64url')) && JSON.parse(Buffer.from(b2, 'base64url')).aud === `http://127.0.0.1:${pushPort}`, 'توقيع VAPID (ES256) صحيح'); }
      await wait(200); ok(pushes.filter(z => z.url === '/nurse').length === 0, 'من قام بالفعل لا يستلم إشعاراً عن فعلته');
      r = await J('POST', `/api/patients/${np.id}/enter`, N); ok(r.s === 200, 'الممرضة تُدخل المريض');
      g = await got('/doctor', 2); ok(g.length === 2 && decryptPush(g[1].body, D.e, D.auth).type === 'enter', 'الطبيب يستلم دفعاً عند الدخول');
      r = await J('POST', `/api/patients/${np.id}/finish`, A, { treatment: 'استشارة', price: 0 }); ok(r.s === 200, 'الطبيب ينهي المعاينة');
      g = await got('/nurse'); ok(g.length === 1, 'الممرضة تستلم دفعاً عند انتهاء المعاينة'); const m2 = decryptPush(g[0].body, NU.e, NU.auth); ok(m2.title.includes('finished') && m2.body.includes('مريض الدفع'), 'نص الإشعار بلغة الممرضة (إنجليزي)');
      await wait(200); ok(pushes.filter(z => z.url === '/doctor').length === 2, 'الطبيب لا يستلم إشعار إنهائه');
      /* تخطي الدور */
      const q1 = (await J('POST', '/api/patients', N, pat('أول'))).j, q2 = (await J('POST', '/api/patients', N, pat('ثاني'))).j; await got('/doctor', 3);
      r = await J('POST', `/api/patients/${q2.id}/enter`, N); ok(r.s === 202, 'طلب تخطي'); let m3 = null;   // الرسائل قد تصل بترتيب مختلف: نبحث عن طلب التخطي بدل افتراض أنه الأخير
      for (let i = 0; i < 40 && !m3; i++) { g = await got('/doctor', 5); m3 = g.map(x => decryptPush(x.body, D.e, D.auth)).find(x => x.type === 'skip_request') || null; if (!m3) await wait(50); } ok(m3.type === 'skip_request' && m3.urgent && m3.body.includes('أول') && m3.body.includes('ثاني'), 'طلب التخطي يصل دفعاً عاجلاً بالاسمين');
      /* عزل العيادات */
      const before = pushes.length; await J('POST', '/api/patients', B, pat('عيادة ب')); await wait(300); ok(pushes.length === before, 'عيادة أخرى لا تُرسل ولا تستقبل إشعارات عيادة أ');
      /* حذف الاشتراك عند الخروج وعند 410 */
      r = await J('DELETE', '/api/push/subscribe', N); ok(r.s === 200, 'حذف اشتراك الممرضة'); const nb = pushes.length;
      await J('POST', `/api/patients/${q2.id}/skip`, A, { allow: false }); await wait(300); ok(pushes.length === nb, 'لا دفع بعد إلغاء الاشتراك');
      const GN = mkSub('/gone'); await J('POST', '/api/push/subscribe', N, { subscription: GN.sub }); await J('POST', `/api/patients/${q2.id}/skip`, A, { allow: false }); await got('/gone'); await wait(200);
      const gl = pushes.length; await J('POST', `/api/patients/${q2.id}/skip`, A, { allow: false }); await wait(300); ok(pushes.length === gl, 'اشتراك منتهٍ (410) يُحذف تلقائياً'); }

    console.log('الإحصائيات');
    { const SD = (await J('POST', '/api/register', null, { clinicName: 'عيادة إحصاء', doctorName: 'د. نور', username: 'stats1', password: 'password9' })).j.token;
      const SN = (await J('POST', '/api/nurses', SD, { name: 'ليلى', phone: '', password: 'nurse123' }), (await J('POST', '/api/login/nurse', null, { code: (await J('GET', '/api/state', SD)).j.me.code, name: 'ليلى', password: 'nurse123' })).j.token);
      let r = await J('GET', '/api/stats?tz=0', SD); ok(r.s === 200 && r.j.summary.visits === 0 && r.j.series.length >= 1, 'إحصائيات عيادة فارغة بلا أخطاء');
      const visit = async (tok, who, treat, teeth, price, paid, extra) => { const p0 = (await J('POST', '/api/patients', tok, pat(who, extra))).j; await J('POST', `/api/patients/${p0.id}/enter`, SD); return (await J('POST', `/api/patients/${p0.id}/finish`, SD, { treatment: treat, teeth, price, paid, followUp: false, notes: '' })); };
      await visit(SD, 'سمير', 'قلع', ['16', '17'], 5000, 5000);
      await visit(SN, 'منى', 'علاج عصب', ['36'], 8000, 3000, { gender: 'أنثى', birthYear: 2015 });
      await visit(SD, 'سمير', 'استشارة', [], 1000, 0, { tooth: 'غير محدد' });
      await visit(SN, 'كريم', 'قلع', ['55'], 4000, 4000, { birthYear: 2018 });
      r = await J('GET', '/api/stats?tz=0', SD); const d = r.j;
      ok(r.s === 200 && d.summary.visits === 4 && d.summary.patients === 3, 'عدد الزيارات 4 والمرضى المختلفون 3');
      ok(d.summary.billed === 18000 && d.summary.collected === 12000 && d.summary.outstanding === 6000, 'المستحق 18000 / المحصَّل 12000 / المتبقي 6000');
      ok(d.treatments.find(x => x.name === 'قلع').visits === 2 && d.treatments[0].name === 'قلع', 'توزيع العلاجات مرتّب بالأكثر');
      ok(d.gender['أنثى'].visits === 1 && d.gender['ذكر'].visits === 3, 'توزيع الجنس');
      ok(d.teeth.perTooth['16'] === 1 && d.teeth.total === 4 && d.teeth.dentition.primary === 1 && d.teeth.jaw.upper === 3 && d.teeth.jaw.lower === 1 && d.teeth.none === 1, 'خريطة الأسنان: دائمة/لبنية/فك/زيارات بلا سن');
      ok(d.debt.total === 6000 && d.debt.count === 2 && d.debt.top[0].name === 'منى', 'الديون: الإجمالي وأكبر مدين');
      ok(d.patients.new === 3 && d.patients.returning === 0 && d.patients.freq[1] === 1, 'مرضى جدد وتكرار الزيارة');
      ok(d.registrars.find(x => x.role === 'nurse' && x.name === 'ليلى').n === 2 && d.registrars.find(x => x.role === 'doctor').n === 2, 'من سجّل المرضى (ممرضة باسمها / طبيب)');
      ok(d.hours.reduce((x, y) => x + y, 0) === 4 && d.heat.flat().reduce((x, y) => x + y, 0) === 4 && d.today.finished === 4, 'الساعات والخريطة الحرارية ولمحة اليوم');
      ok(d.series.reduce((x, y) => x + y.visits, 0) === 4 && d.series.reduce((x, y) => x + y.collected, 0) === 12000, 'السلسلة الزمنية تطابق المجاميع');
      const day = new Date().toISOString().slice(0, 10);
      r = await J('GET', `/api/stats?from=${day}&to=${day}&tz=0`, SD); ok(r.j.summary.visits === 4 && r.j.prev && r.j.prev.visits === 0, 'نطاق اليوم + فترة سابقة للمقارنة');
      r = await J('GET', '/api/stats?from=2001-01-01&to=2001-01-31&tz=0', SD); ok(r.j.summary.visits === 0 && r.j.series.length === 31 && r.j.debt.total === 6000, 'نطاق فارغ: أيام بلا زيارات، والديون كلية');
      r = await J('GET', '/api/stats?from=2020-01-01&tz=0', SD); ok(r.j.range.gran === 'month' && r.j.series.length > 60, 'نطاق طويل يُجمَّع شهرياً');
      const pay = (await J('GET', '/api/archive?limit=50', SD)).j.items.find(x => x.name === 'منى'); await J('POST', `/api/archive/${pay.id}/payment`, SD, { amount: 5000 });
      r = await J('GET', '/api/stats?tz=0', SD); ok(r.j.summary.collected === 17000 && r.j.debt.total === 1000 && r.j.debt.count === 1, 'دفعة لاحقة تُحتسب في المحصَّل وتُنقص الديون');
      r = await J('GET', '/api/stats', SN); ok(r.s === 403, 'الممرضة لا تصل للإحصائيات');
      r = await J('GET', '/api/stats'); ok(r.s === 401, 'بلا دخول: مرفوض');
      const SD2 = (await J('POST', '/api/register', null, { clinicName: 'عيادة أخرى', doctorName: 'د. هدى', username: 'stats2', password: 'password9' })).j.token;
      { const q = (await J('POST', '/api/patients', SD2, pat('وحيد'))).j; await J('POST', `/api/patients/${q.id}/enter`, SD2); await J('POST', `/api/patients/${q.id}/finish`, SD2, { treatment: 'قلع', teeth: ['11'], price: 700, paid: 0 }); }
      r = await J('GET', '/api/stats?tz=0', SD2); ok(r.s === 200 && r.j.summary.visits === 1 && r.j.debt.total === 700 && r.j.patients.unique === 1, 'عزل: عيادة أخرى ترى أرقامها فقط');
      r = await J('GET', '/api/stats?tz=0', SD); ok(r.j.summary.visits === 4 && r.j.debt.total === 1000, 'عزل: إحصائيات العيادة الأولى لم تتأثر');
      r = await J('GET', '/api/stats?from=zzz&to=%00&tz=abc', SD); ok(r.s === 200, 'مدخلات تواريخ فاسدة لا تُسقط الخادم'); }

    console.log('الوصفات الطبية');
    { const RD = (await J('POST', '/api/register', null, { clinicName: 'عيادة وصفات', doctorName: 'د. وصفة', username: 'rxdoc1', password: 'password9' })).j.token;
      const RD2 = (await J('POST', '/api/register', null, { clinicName: 'عيادة وصفات 2', doctorName: 'د. ثانٍ', username: 'rxdoc2', password: 'password9' })).j.token;
      const RN = (await J('POST', '/api/nurses', RD, { name: 'سلمى', phone: '', password: 'nurse123' }), (await J('POST', '/api/login/nurse', null, { code: (await J('GET', '/api/state', RD)).j.me.code, name: 'سلمى', password: 'nurse123' })).j.token);
      let r = await J('GET', '/api/rx', RD); ok(r.s === 200 && Array.isArray(r.j.basket) && r.j.basket.length === 0 && r.j.drugs.length === 0, 'سلة وقاعدة أدوية فارغتان في البداية');
      r = await J('GET', '/api/rx', RN); ok(r.s === 403, 'الممرضة لا ترى السلة'); r = await J('PUT', '/api/rx/basket', RN, { items: [{ name: 'x' }] }); ok(r.s === 403, 'الممرضة لا تعدّل السلة');
      r = await J('GET', '/api/rx'); ok(r.s === 401, 'بلا دخول: مرفوض');
      r = await J('PUT', '/api/rx/basket', RD, { items: [{ name: ' Amoxicilline ', form: 'gél 500 mg', dose: '1 gél', freq: '3 fois/j', dur: '7 j' }, { name: 'amoxicilline', form: 'GÉL 500 MG' }, { name: 'Paracétamol', form: 'cp 1 g' }, { name: '' }, 5, null, { form: 'بلا اسم' }, { name: 'A'.repeat(500), form: 'f'.repeat(500), note: 'n'.repeat(500) }] });
      ok(r.s === 200 && r.j.length === 3, 'السلة: تُحذف المكررة والفارغة وغير الصالحة');
      ok(r.j[0].name === 'Amoxicilline' && r.j[0].dose === '1 gél' && /^[a-f0-9]{12}$/.test(r.j[0].id), 'السلة: تقليم الاسم + حفظ الجرعة الافتراضية + معرّف مولّد');
      ok(r.j[2].name.length === 120 && r.j[2].form.length === 160 && r.j[2].note.length === 200, 'السلة: حدود أطوال الحقول');
      const many = Array.from({ length: 150 }, (_, i) => ({ name: 'دواء' + i })); r = await J('PUT', '/api/rx/basket', RD, { items: many }); ok(r.s === 200 && r.j.length === 100, 'السلة: حدّ 100 دواء');
      r = await J('PUT', '/api/rx/basket', RD, { items: [{ name: 'Ibuprofène', form: 'cp 400 mg', dose: '1 cp', freq: '3 fois/j', dur: '3 j' }] }); const keepId = r.j[0].id;
      r = await J('PUT', '/api/rx/basket', RD, { items: [{ id: keepId, name: 'Ibuprofène', form: 'cp 400 mg', dose: '1 cp', freq: '2 fois/j', dur: '5 j' }] }); ok(r.j[0].id === keepId && r.j[0].freq === '2 fois/j', 'السلة: تحديث دواء موجود يُبقي معرّفه');
      r = await J('GET', '/api/rx', RD2); ok(r.j.basket.length === 0, 'عزل: سلة عيادة أخرى فارغة');
      r = await J('GET', '/api/rx', RD); ok(r.j.template === null, 'قالب الوصفة: افتراضي في البداية');
      r = await J('PUT', '/api/rx/template', RN, { clinic: 'x' }); ok(r.s === 403, 'الممرضة لا تعدّل قالب الوصفة');
      r = await J('PUT', '/api/rx/template', RD, { clinic: ' عيادة الأمل ', doctor: null, spec: 'جراحة الأسنان', phone: '0550 00 00 00', address: 'x'.repeat(400), logo: 'data:image/png;base64,iVBORw0KGgo=', lang: 'fr' });
      ok(r.s === 200 && r.j.clinic === 'عيادة الأمل' && r.j.doctor === null && r.j.phone === '0550 00 00 00' && r.j.address.length === 160 && r.j.lang === 'fr' && r.j.logo.startsWith('data:image/png'), 'قالب الوصفة: حفظ وتقليم');
      r = await J('PUT', '/api/rx/template', RD, { logo: 'data:text/html;base64,PHNjcmlwdD4=', lang: 'zz', clinic: 5 }); ok(r.j.logo === '' && r.j.lang === 'ar', 'قالب الوصفة: يرفض شعاراً غير صورة ولغة غير معروفة');
      r = await J('PUT', '/api/rx/template', RD, { clinic: 'عيادة الأمل', lang: 'en' }); r = await J('GET', '/api/rx', RD2); ok(r.j.template === null, 'عزل: قالب عيادة أخرى لم يتأثر');
      r = await J('PUT', '/api/rx/drugs', RD, { drugs: [['Foo', 'فو', 'Foobar, Foox', 'cp 10 mg; sirop', 'تجريبي'], { n: 'Bar', b: 'Barx', f: 'gél 5 mg' }, 'Baz', { name: '' }, 7, ['']] });
      ok(r.s === 200 && r.j.count === 3, 'استيراد أدوية: يُقبل الصالح فقط (3)');
      r = await J('GET', '/api/rx', RD); ok(r.j.drugs.length === 3 && r.j.drugs[0].length === 5 && r.j.drugs[1][0] === 'Bar' && r.j.drugs[1][2] === 'Barx' && r.j.drugs[2][0] === 'Baz', 'قاعدة الأدوية المستوردة تُحفظ بصيغة موحّدة');
      r = await J('GET', '/api/rx', RD2); ok(r.j.drugs.length === 0, 'عزل: قاعدة العيادة الأخرى لم تتأثر');
      r = await J('PUT', '/api/rx/drugs', RD, { drugs: Array.from({ length: 9000 }, (_, i) => ['D' + i, '', '', '', '']) }); ok(r.s === 200 && r.j.count === 8000, 'استيراد أدوية: حدّ 8000');
      r = await J('DELETE', '/api/rx/drugs', RD); ok(r.s === 200 && r.j.count === 0 && (await J('GET', '/api/rx', RD)).j.drugs.length === 0, 'حذف الأدوية المستوردة');

      const finishRx = async (name, rx, extra) => { const p0 = (await J('POST', '/api/patients', RD, pat(name, extra))).j; await J('POST', `/api/patients/${p0.id}/enter`, RD); return await J('POST', `/api/patients/${p0.id}/finish`, RD, { treatment: 'قلع', teeth: ['16'], price: 1000, paid: 1000, notes: '', rx }); };
      r = await finishRx('مريض وصفة', [{ name: ' Amoxicilline ', form: 'gél 500 mg', dose: '1 gél', freq: '3 fois/j', dur: '7 j', note: 'بعد الأكل' }, { name: 'Ibuprofène', form: 'cp 400 mg', dose: '1', freq: 'عند اللزوم', dur: '3 j' }, { name: '' }, 'x', null, { name: '<img src=x onerror=1>', form: '', dose: '', freq: '', dur: '', note: '' }]);
      ok(r.s === 200 && r.j.rx.length === 3 && r.j.rx[0].name === 'Amoxicilline' && r.j.rx[0].note === 'بعد الأكل', 'إنهاء المعاينة يحفظ الوصفة وينقّيها (3 أسطر صالحة)');
      const rxId = r.j.id; r = await J('GET', '/api/archive?limit=50', RD); const rec = r.j.items.find(x => x.id === rxId); ok(rec && rec.rx.length === 3 && rec.rx[1].freq === 'عند اللزوم', 'الأرشيف يعرض الوصفة المحفوظة');
      r = await J('GET', '/api/history?name=' + encodeURIComponent('مريض وصفة') + '&year=1990', RD); ok(r.s === 200 && r.j.records[0].rx.length === 3, 'سجل المريض يعرض الوصفة');
      r = await finishRx('بلا وصفة', undefined); ok(r.s === 200 && Array.isArray(r.j.rx) && r.j.rx.length === 0, 'زيارة بلا وصفة: مصفوفة فارغة');
      r = await finishRx('وصفة طويلة', Array.from({ length: 40 }, (_, i) => ({ name: 'دواء' + i }))); ok(r.j.rx.length === 25, 'وصفة: حدّ 25 سطراً');
      r = await J('GET', '/api/stats?tz=0', RD); ok(r.j.rx.prescriptions === 2 && r.j.rx.top[0].n >= 1 && r.j.rx.lines === 28, 'الإحصائيات: عدد الوصفات وأسطر الأدوية وأكثر الأدوية وصفاً');
      r = await J('GET', '/api/stats?tz=0', RD2); ok(r.j.rx.prescriptions === 0 && r.j.rx.top.length === 0, 'عزل: إحصائيات الأدوية لعيادة أخرى فارغة');
      /* نسخ احتياطي واستعادة */
      await J('PUT', '/api/rx/drugs', RD, { drugs: [['Foo', '', 'Foobar', 'cp 10 mg', '']] });
      const bk = await J('GET', '/api/backup', RD); ok(bk.s === 200 && Array.isArray(bk.j.rxBasket) && bk.j.rxBasket.length === 1 && bk.j.rxDrugs.length === 1, 'النسخة الاحتياطية تشمل السلة وقاعدة الأدوية');
      await J('PUT', '/api/rx/basket', RD, { items: [] }); await J('DELETE', '/api/rx/drugs', RD);
      r = await J('POST', '/api/restore', RD, bk.j); ok(r.s === 200, 'استعادة النسخة');
      r = await J('GET', '/api/rx', RD); ok(r.j.basket.length === 1 && r.j.basket[0].name === 'Ibuprofène' && r.j.drugs.length === 1, 'الاستعادة تعيد السلة وقاعدة الأدوية');
      r = await J('GET', '/api/archive?limit=50', RD); ok(r.j.items.find(x => x.name === 'مريض وصفة').rx.length === 3, 'الاستعادة تحفظ وصفات الأرشيف');
      const old = { ...bk.j }; delete old.rxBasket; delete old.rxDrugs; await J('POST', '/api/restore', RD, old); r = await J('GET', '/api/rx', RD); ok(r.j.basket.length === 1, 'استعادة نسخة قديمة (بلا سلة) لا تمسح السلة الحالية'); }

    console.log('مالك التطبيق: الموافقة على الحسابات ومراقبتها');
    { let r = await J('POST', '/api/owner/login', null, { password: 'wrong' }); ok(r.s === 401, 'كلمة مرور مالك خاطئة تُرفض');
      r = await J('GET', '/api/owner/clinics'); ok(r.s === 401, 'قائمة الحسابات تتطلب دخول المالك');
      r = await J('GET', '/api/owner/clinics', 'bogus'); ok(r.s === 401, 'رمز مالك مزيّف مرفوض');
      const ownerLogin = await J('POST', '/api/owner/login', null, { password: 'owner-pass-123' }); ok(ownerLogin.s === 200 && ownerLogin.j.token, 'دخول المالك'); const O = ownerLogin.j.token;
      const docTok = (await J('POST', '/api/login/doctor', null, { username: 'sara', password: 'password2' })).j.token;
      r = await J('GET', '/api/owner/clinics', docTok); ok(r.s === 401, 'رمز طبيب لا يفتح لوحة المالك');
      r = await J('GET', '/api/owner/clinics', O); ok(r.s === 200 && r.j.clinics.length > 3 && r.j.clinics.every(c => c.status === 'active'), 'المالك يرى كل الحسابات والقديمة فعّالة');
      ok(r.j.clinics.every(c => !('patientsData' in c) && !c.password && !c.hash && !c.salt), 'القائمة لا تكشف كلمات مرور ولا بيانات مرضى');
      ok(r.j.clinics.some(c => c.nurses >= 1 && c.code && c.name && c.doctor && c.lastLoginAt), 'عدّادات العيادة ورمزها وآخر دخول ظاهرة للمالك');
      r = await J('POST', '/api/owner/settings', O, { requireApproval: true }); ok(r.s === 200 && r.j.approval === true, 'تفعيل اشتراط الموافقة');
      r = await J('GET', '/api/config'); ok(r.j.approval === true, 'الإعدادات العامة تعلن اشتراط الموافقة');
      r = await J('POST', '/api/register', null, { clinicName: 'عيادة معلّقة', doctorName: 'د. معلّق', username: 'pend1', password: 'password1' });
      ok(r.s === 202 && r.j.pending && !r.j.token, 'التسجيل الجديد يبقى معلّقاً بلا جلسة');
      r = await J('POST', '/api/login/doctor', null, { username: 'pend1', password: 'password1' }); ok(r.s === 403 && r.j.error === 'pending', 'الدخول مرفوض قبل الموافقة');
      r = await J('POST', '/api/login/doctor', null, { username: 'pend1', password: 'bad-password' }); ok(r.s === 401, 'كلمة مرور خاطئة لا تكشف حالة الحساب');
      r = await J('POST', '/api/register', null, { clinicName: 'x', doctorName: 'y', username: 'pend1', password: 'password1' }); ok(r.s === 409, 'اسم المستخدم المعلّق محجوز');
      r = await J('GET', '/api/owner/clinics', O); const pend = r.j.clinics.find(c => c.username === 'pend1');
      ok(pend && pend.status === 'pending' && r.j.clinics[0].username === 'pend1', 'الطلب المعلّق يظهر للمالك أولاً');
      r = await J('POST', `/api/owner/clinics/${pend.id}/suspend`, O); ok(r.s === 409, 'لا يُوقَف حساب معلّق');
      r = await J('POST', `/api/owner/clinics/${pend.id}/approve`, O); ok(r.s === 200 && r.j.status === 'active', 'قبول الحساب');
      r = await J('POST', '/api/login/doctor', null, { username: 'pend1', password: 'password1' }); ok(r.s === 200 && r.j.token, 'الدخول ينجح بعد الموافقة'); const PT = r.j.token;
      const pcode = (await J('GET', '/api/state', PT)).j.me.code;
      await J('POST', '/api/nurses', PT, { name: 'ممرضة م', phone: '0661', password: 'nurse123' });
      r = await J('POST', '/api/login/nurse', null, { code: pcode, name: 'ممرضة م', password: 'nurse123' }); ok(r.s === 200, 'الممرضة تدخل بعد الموافقة'); const PN = r.j.token;
      r = await J('POST', `/api/owner/clinics/${pend.id}/suspend`, O); ok(r.s === 200 && r.j.status === 'suspended', 'إيقاف الحساب');
      r = await J('GET', '/api/state', PT); ok(r.s === 401 || r.s === 403, 'جلسة الطبيب تُقطع فوراً عند الإيقاف');
      r = await J('GET', '/api/state', PN); ok(r.s === 401 || r.s === 403, 'جلسة الممرضة تُقطع فوراً عند الإيقاف');
      r = await J('POST', '/api/login/doctor', null, { username: 'pend1', password: 'password1' }); ok(r.s === 403 && r.j.error === 'suspended', 'الطبيب الموقوف لا يدخل');
      r = await J('POST', '/api/login/nurse', null, { code: pcode, name: 'ممرضة م', password: 'nurse123' }); ok(r.s === 403, 'الممرضة في عيادة موقوفة لا تدخل');
      r = await J('POST', `/api/owner/clinics/${pend.id}/activate`, O); ok(r.s === 200 && r.j.status === 'active', 'إعادة التفعيل');
      r = await J('POST', '/api/login/doctor', null, { username: 'pend1', password: 'password1' }); ok(r.s === 200, 'يدخل بعد إعادة التفعيل وبياناته محفوظة');
      r = await J('GET', '/api/state', docTok); ok(r.s === 200, 'حسابات الآخرين لم تتأثر');
      r = await J('POST', '/api/register', null, { clinicName: 'للرفض', doctorName: 'د. ر', username: 'rej1', password: 'password1' }); ok(r.s === 202, 'طلب جديد للرفض');
      const rej = (await J('GET', '/api/owner/clinics', O)).j.clinics.find(c => c.username === 'rej1');
      r = await J('DELETE', `/api/owner/clinics/${rej.id}`, O); ok(r.s === 200, 'رفض الطلب وحذفه');
      r = await J('POST', '/api/login/doctor', null, { username: 'rej1', password: 'password1' }); ok(r.s === 401, 'المحذوف لا يدخل');
      r = await J('POST', '/api/register', null, { clinicName: 'جديد', doctorName: 'د. ج', username: 'rej1', password: 'password1' }); ok(r.s === 202, 'يمكن إعادة استخدام اسم المستخدم بعد الحذف');
      r = await J('DELETE', '/api/owner/clinics/ffffffffffffffff', O); ok(r.s === 404, 'حذف حساب غير موجود');
      r = await J('POST', '/api/owner/settings', O, { requireApproval: false }); r = await J('POST', '/api/register', null, { clinicName: 'مفتوح', doctorName: 'د. م', username: 'open1', password: 'password1' });
      ok(r.s === 201 && r.j.token, 'عند إيقاف الاشتراط يعود التسجيل الفوري');
      r = await J('POST', '/api/owner/logout', O); r = await J('GET', '/api/owner/clinics', O); ok(r.s === 401, 'خروج المالك يُبطل رمزه');
      const pg = await fetch(base + '/owner'); ok(pg.status === 200 && (await pg.text()).includes('owner.js') && /noindex/.test(pg.headers.get('x-robots-tag') || ''), 'صفحة /owner تُخدَّم وغير مفهرسة');
    }

    console.log('الملفات الثابتة والأمان');
    for (const f of ['/', '/app.js', '/qr.js', '/numpad.js', '/style.css', '/sw.js', '/manifest.webmanifest', '/icons/icon-192.png', '/t/abc123abc123abc123abc123']) { const x = await fetch(base + f); ok(x.status === 200, 'GET ' + f); }
    { const idx = await (await fetch(base + '/')).text(), sw = await (await fetch(base + '/sw.js')).text();
      ok(idx.includes('src="numpad.js"'), 'لوحة الأرقام مضمّنة في الصفحة'); ok(sw.includes("'/numpad.js'"), 'لوحة الأرقام ضمن ملفات التخزين المؤقت'); }
    let x = await fetch(base + '/..%2fserver.js'); ok(x.status !== 200, 'منع تجاوز المسار');
    x = await fetch(base + '/%2e%2e/server.js'); ok(x.status !== 200, 'منع تجاوز المسار 2');
    x = await fetch(base + '/data/db.json'); ok(x.status === 404, 'قاعدة البيانات غير مكشوفة');
    ok((await fetch(base + '/')).headers.get('content-security-policy').includes("script-src 'self'"), 'سياسة CSP');
    console.log(`\nنجحت كل الاختبارات: ${pass}`);
  } catch (e) { console.error('\n✗ فشل:', e.message); process.exitCode = 1; }
  srv.on('exit', () => fs.rmSync(dir, { recursive: true, force: true })); srv.kill(); mock.close();
})();
